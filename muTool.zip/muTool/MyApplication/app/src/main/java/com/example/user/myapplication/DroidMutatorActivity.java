package com.example.user.myapplication;

import android.app.Activity;
import android.os.Handler;
import android.os.Message;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class DroidMutatorActivity extends Activity {
    Button btn;
    TextView textView;
    Handler handler = new Handler();
    private int COMPUTE_FINISHED = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_droid_mutator);
        btn = (Button) findViewById(R.id.btn);
        textView = (TextView) findViewById(R.id.textView);
        btn.setOnClickListener(new Listener());
    }
    class Listener implements View.OnClickListener{
        public void onClick(View view){
            int num = getData();
            if(num >  0){
                setTextView("computing...");
                new DroidMutatorThread(num).start();
            }else {
                printMessage(num+num);
            }
        }
    }
    class DroidMutatorThread extends Thread{
        int  num;
        DroidMutatorThread(int num){
            this.num = num;
        }
        public void run(){
            Message msg = Message.obtain();
            msg.what = num + num;
            handler.sendMessage(msg);
        }
    }
    private void setTextView(String str){
        textView.setText(str);
    }

    private void printMessage(int num){
        System.out.println("Sum of num : "+ num);
    }

    public int getData(){
        return 10;
    }

    private boolean needComputeData(){
        return true;
    }

    private void computeData(long[] datas){
        handler.post(new Runnable() {
            @Override
            public void run() {
                System.out.println("I'm in computeData method.");
            }
        });
    }
}
