package com.example.user.myapplication;

import android.os.Bundle;
import android.widget.TextView;

import java.io.File;
import java.io.FileReader;
import java.net.URI;

public class SecondActivity extends MainActivity implements Runnable{
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        textView = (TextView)findViewById(R.id.tv_show);
        Bundle bundle = this.getIntent().getExtras();
        String msg = bundle.getString("msg");
        textView.setText(msg);
    }

    @Override
    public void run() {
        File file = new File("E:\\mutatorHome:\\mutants.xlsx");
    }
}
