package com.example.user.myapplication;

import android.os.AsyncTask;

import java.util.Date;

public class MyAsyncTask extends AsyncTask<Long, Void, Void> {

    protected Void doInBackground(Long... args) {
        Date date = new Date(1,2,3);
        return null;
    }

    public void testFunc(){

    }

    public void testFunc2(int a){
        System.out.println(a);
    }

    public int testFunc2(int a,int b){
        System.out.println(a+b);
        return b;
    }
}
