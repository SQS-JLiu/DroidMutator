package com.example.user.myapplication;

import android.os.Message;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

public class TestDemo extends TestThread{
    public void test(){
        System.out.println("Just test...");
    }

    public void run(){
        final int maxNum =0;
        try {
            URI uri = new URI(String.valueOf(maxNum));
            File file = new File("E:\\mutatorHome:\\mutants.xlsx");
            FileReader fr = new FileReader(file);
            fr.close();
        }catch (URISyntaxException uriExcept){
            uriExcept.printStackTrace();
        }catch (IOException ioe){
            ioe.printStackTrace();
        }
    }

    public void fun(){
        int a=0;
        if(a > 1){
            File file = new File("E:\\mutatorHome:\\mutants.xlsx");
        }
    }
    public void fun(int a,char b){
        if(a > b){
            File file = new File("E:\\mutatorHome:\\mutants.xlsx");
        }
    }

    public void fun(int b,int a){
        System.out.println(a+b);
        File file = new File("E:\\mutatorHome:\\mutants.xlsx");
    }

    @Override
    public boolean handleMessage(Message msg) {
        if(msg != null){
            System.out.println(msg.getData().getInt("data"));
        }
        File file = new File("E:\\mutatorHome:\\mutants.xlsx");
        return false;
    }
}
