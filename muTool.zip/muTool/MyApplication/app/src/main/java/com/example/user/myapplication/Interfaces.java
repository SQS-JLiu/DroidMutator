package com.example.user.myapplication;

interface Interfaces extends Runnable{
}
