package com.example.user.myapplication;

import java.io.File;

public class TestMuitiImplement implements Interfaces{
    @Override
    public void run() {
        File file = new File("E:\\mutatorHome:\\mutants.xlsx");
    }
}
