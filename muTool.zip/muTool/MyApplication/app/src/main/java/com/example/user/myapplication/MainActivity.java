package com.example.user.myapplication;

import android.app.Activity;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.location.Location;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileReader;

import java.io.FileWriter;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Date;

public class MainActivity extends Activity {//AppCompatActivity
    private Button buttonLogin,buttonReset;
    private EditText editTextId,editTextPassword;
    private int data = 1;
    private int[] array = {0,1,2};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buttonLogin =(Button) findViewById(R.id.btn_login);
        buttonReset = (Button)findViewById(R.id.btn_reset);
        editTextId = (EditText)findViewById(R.id.et_id);
        editTextPassword = (EditText)findViewById(R.id.et_passwd);
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String str = editTextId.getText().toString()+":"+editTextPassword.getText().toString();
                Toast.makeText(MainActivity.this,str,Toast.LENGTH_SHORT).show();
                Bundle bundle = new Bundle();
                bundle.putString("msg","I'm in second activity.");
                Intent intent = new Intent();
                intent.setAction("android.intent.activity_second.action");
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
        buttonReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)  {
                editTextId.setText("a");
                editTextPassword.setText("");
                final ProgressDialog dialog = new ProgressDialog(MainActivity.this);
                dialog.setTitle("progress");
                dialog.show();
                test();
                new AsyncTask<Long, Void, Void>() {

                    protected void onPreExecute() {
                        //dialog.setMax(10);
                        Toast.makeText(MainActivity.this,"Starting progress...",Toast.LENGTH_SHORT).show();
                        super.onPreExecute();
                    }
                    protected Void doInBackground(Long... args) {
                        for(int i=0;i<1;i++){
                          System.out.println(i);
                        }
                        return null;
                    }
                    protected void onPostExecute(Void aVoid) {
                        dialog.dismiss();
                        Toast.makeText(MainActivity.this,"After progress...",Toast.LENGTH_SHORT).show();
                    }
                }.execute(2L);
            }
        });
    }

    public void test(){
        new Thread(){
            public void run(){
                TestDemo testDemo = new TestDemo();
                int a=1,b=2,c=3,d;
                int[] array = new int[10];
                for (int i = 0; i < 10; i++) {
                    array[i] = 0;
                }
                boolean aa=true;
                arrayFunc(array,testDemo);
                if (aa != true) {
                        a++;
                }
                else {
                   b++;
                }
                if(testDemo == null){
                    System.out.println("test...");
                }
            }
        }.start();

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent("");
                Bundle bundle = new Bundle();
                intent.setAction("android.intent.activity_second.action");
                intent.putExtra("name","testName");
                intent.putExtras(bundle);
                startActivity(intent);
                editTextId = findViewById(R.id.et_id);
                Date date = new Date(1,2,3);
            }
        });
        System.out.println("I'm Test:"+data);
    }


    class TestAsynctask extends  AsyncTask<Long, Void, Void>{

        private int a = 1;
        private int b = 2;

        protected Void doInBackground(Long... args) {
            final int maxNum = max(a,b);
            new Handler().post(new Runnable() {
                @Override
                public void run() {
                    Location GPSLocation = new Location("");
                    BluetoothAdapter btAdapter = BluetoothAdapter.getDefaultAdapter();
                    try {
                        URI uri = new URI(String.valueOf(maxNum));
                        File file = new File("E:\\mutatorHome:\\mutants.xlsx");
                        FileReader fr = new FileReader(file);
                        fr.close();
                    }catch (URISyntaxException uriExcept){
                        uriExcept.printStackTrace();
                    }catch (IOException ioe){
                        ioe.printStackTrace();
                    }
                }
            });
            return null;
        }
    }

    public static void arrayFunc(int arr[],TestDemo testDemo) {
        for (int i = 0; i < arr.length; i++) {
            System.out.println(arr[1]);
        }
        new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(Message msg) {
                int a=0,b=-a;
                switch(++a){
                    case 1:
                        break;
                    case -1:
                        break;
                    case 2:
                        break;
                }
                return false;
            }
        });
    }

    public int max(int a,int b){
        return   a > b ? a : b;
    }
}
