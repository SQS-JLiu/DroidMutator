package com.example.user.myapplication;

import android.os.Handler;
import android.os.Message;

public class TestThread extends Thread implements Handler.Callback {
    private void test(){
        System.out.println();
    }

    @Override
    public void run() {
        super.run();
        System.out.println();
    }

    @Override
    public boolean handleMessage(Message msg) {
        return false;
    }
}
